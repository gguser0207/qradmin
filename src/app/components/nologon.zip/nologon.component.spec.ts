import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NologonComponent } from './nologon.component';

describe('NologonComponent', () => {
  let component: NologonComponent;
  let fixture: ComponentFixture<NologonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NologonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NologonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
